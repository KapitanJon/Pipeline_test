"""Adds 1 to the input """
def plus_one(number):
    return number + 1

